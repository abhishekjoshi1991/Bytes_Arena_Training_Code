import React from 'react'
import './css/loader.css'

export default function Loader() {
  return (
    <div id="loader"></div>
  )
}
